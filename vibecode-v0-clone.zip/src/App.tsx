/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  ClerkProvider, 
  SignedIn, 
  SignedOut, 
  SignInButton, 
  UserButton, 
  useUser 
} from '@clerk/clerk-react';
import { 
  BrowserRouter as Router, 
  Routes, 
  Route, 
  Link, 
  useNavigate,
  useLocation
} from 'react-router-dom';
import { 
  Sparkles, 
  Send, 
  Layout, 
  Layers, 
  Monitor, 
  Smartphone, 
  ChevronRight, 
  RefreshCw,
  Code,
  Eye,
  Save,
  LayoutGrid,
  History as HistoryIcon,
  Settings as SettingsIcon,
  Palette,
  Type as TypeIcon,
  X,
  Check,
  Zap,
  Maximize2,
  Trash2,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GeminiService, LandingPageDesign } from './services/geminiService';
import { CanvasBackground } from './components/CanvasBackground';
import { PreviewModal } from './components/PreviewModal';
import { Dashboard } from './components/Dashboard';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import confetti from 'canvas-confetti';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const CLERK_PUBLISHABLE_KEY = "pk_test_aGVyb2ljLWxvdXNlLTkuY2xlcmsuYWNjb3VudHMuZGV2JA";

const FONTS = [
  { name: 'DM Sans', value: 'font-sans' },
  { name: 'Bebas Neue', value: 'font-bebas' },
  { name: 'Playfair Display', value: 'font-playfair' },
  { name: 'Syne', value: 'font-syne' },
  { name: 'Space Grotesk', value: 'font-space' },
  { name: 'Oswald', value: 'font-oswald' },
];

const THEMES = [
  { name: 'Purple', value: 'purple' },
  { name: 'Blue', value: 'blue' },
  { name: 'Red', value: 'red' },
  { name: 'Green', value: 'green' },
  { name: 'Pink', value: 'pink' },
  { name: 'Orange', value: 'orange' },
  { name: 'Cyan', value: 'cyan' },
  { name: 'Gold', value: 'gold' },
];

const QUICK_CHIPS = [
  "Cinematic Dark Mode",
  "Ultra Glow & Neon",
  "Minimalist Zen",
  "Futuristic Cyberpunk",
  "Soft Pink Aesthetic",
  "Bold Brutalist",
  "Glassmorphism Pro",
  "High-Motion Animated"
];

const STATUS_MESSAGES = [
  "Analyzing your vibe...",
  "Architecting 6-section layout...",
  "Injecting CSS animations...",
  "Optimizing typography...",
  "Rendering 3 unique variants...",
  "Polishing the pixels..."
];

const getGemini = (() => {
  let instance: GeminiService | null = null;
  return () => {
    if (!instance) instance = new GeminiService();
    return instance;
  };
})();

const VibeCoderApp = () => {
  const { user, isLoaded } = useUser();
  const navigate = useNavigate();
  
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [statusIdx, setStatusIdx] = useState(0);
  const [designs, setDesigns] = useState<LandingPageDesign[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [selectedFont, setSelectedFont] = useState(FONTS[0]);
  const [selectedTheme, setSelectedTheme] = useState(THEMES[0]);
  const [viewMode, setViewMode] = useState<'desktop' | 'mobile'>('desktop');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [savedProjects, setSavedProjects] = useState<any[]>([]);

  // Load saved projects from backend
  const fetchProjects = async () => {
    if (!user) return;
    try {
      const res = await fetch(`/api/projects?userId=${user.id}`);
      const data = await res.json();
      setSavedProjects(data);
    } catch (error) {
      console.error("Failed to fetch projects:", error);
    }
  };

  useEffect(() => {
    if (user) fetchProjects();
  }, [user]);

  // Status animation
  useEffect(() => {
    let interval: any;
    if (isGenerating) {
      interval = setInterval(() => {
        setStatusIdx((prev) => (prev + 1) % STATUS_MESSAGES.length);
      }, 2000);
    } else {
      setStatusIdx(0);
    }
    return () => clearInterval(interval);
  }, [isGenerating]);

  const handleGenerate = async (customPrompt?: string) => {
    if (!user) {
      alert("Please sign in to generate designs.");
      return;
    }
    const activePrompt = customPrompt || prompt;
    if (!activePrompt.trim() || isGenerating) return;

    setIsGenerating(true);
    try {
      const gemini = getGemini();
      const result = await gemini.generateDesigns(activePrompt, {
        font: selectedFont.name,
        theme: selectedTheme.name,
        previousDesigns: designs.length > 0 ? designs : undefined
      });
      setDesigns(result.designs);
      setSelectedIndex(0);
      setPrompt('');
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#7c3aed', '#2563eb']
      });
    } catch (error) {
      console.error("Generation failed:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = async () => {
    if (!user || designs.length === 0) return;
    if (savedProjects.length >= 10) {
      alert("Project limit reached (10/10). Delete some to save more!");
      return;
    }
    const current = designs[selectedIndex];
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          name: current.name,
          description: current.description,
          html: current.html,
          layoutType: current.layoutType,
          font: selectedFont.name,
          theme: selectedTheme.name
        })
      });
      if (res.ok) {
        fetchProjects();
        alert("Project saved to database!");
      }
    } catch (error) {
      console.error("Failed to save project:", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user) return;
    try {
      const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' });
      if (res.ok) fetchProjects();
    } catch (error) {
      console.error("Failed to delete project:", error);
    }
  };

  const currentDesign = designs[selectedIndex];

  return (
    <div className="min-h-screen flex flex-col relative bg-[#050508] mesh-gradient overflow-hidden">
      <CanvasBackground />
      
      {/* Mesh Gradient Overlays */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-accent-purple/10 blur-[120px] rounded-full animate-float"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent-blue/10 blur-[120px] rounded-full animate-float" style={{ animationDelay: '-5s' }}></div>
        
        {/* Butterfly-like floating elements */}
        <motion.div 
          animate={{ 
            x: [0, 100, -50, 0], 
            y: [0, -150, 50, 0],
            rotate: [0, 45, -45, 0],
            scale: [1, 1.2, 0.8, 1]
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/2 left-1/4 w-4 h-4 bg-accent-purple/40 rounded-full blur-md"
        />
        <motion.div 
          animate={{ 
            x: [0, -120, 80, 0], 
            y: [0, 100, -100, 0],
            rotate: [0, -30, 30, 0],
            scale: [1, 0.9, 1.1, 1]
          }}
          transition={{ duration: 30, repeat: Infinity, ease: "easeInOut", delay: 5 }}
          className="absolute bottom-1/3 right-1/3 w-6 h-6 bg-accent-blue/30 rounded-full blur-lg"
        />
        <motion.div 
          animate={{ 
            x: [0, 200, -100, 0], 
            y: [0, 50, -150, 0],
            rotate: [0, 60, -60, 0],
            scale: [1, 1.3, 0.7, 1]
          }}
          transition={{ duration: 35, repeat: Infinity, ease: "easeInOut", delay: 10 }}
          className="absolute top-1/4 right-1/4 w-3 h-3 bg-accent-pink/40 rounded-full blur-sm"
        />
      </div>

      {/* Header */}
      <header className="glass-header px-6 h-16 flex items-center justify-between shrink-0 relative z-50">
        <div className="flex items-center gap-6">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-9 h-9 bg-gradient-to-br from-accent-purple via-accent-blue to-accent-pink rounded-xl flex items-center justify-center shadow-lg shadow-accent-purple/20 group-hover:scale-110 transition-transform duration-500">
              <Sparkles className="w-5 h-5 text-white fill-white" />
            </div>
            <div>
              <span className="font-bold text-lg tracking-tighter block leading-none">VibeCoder</span>
              <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest mt-1 block">AI Design Engine</span>
            </div>
          </Link>
          
          <div className="flex items-center gap-2">
            <div className="flex bg-white/5 p-1 rounded-xl border border-white/10">
              <button onClick={() => setViewMode('desktop')} className={cn("p-1.5 rounded-lg transition-all", viewMode === 'desktop' ? "bg-white/10 text-white" : "text-zinc-500 hover:text-zinc-300")}><Monitor className="w-4 h-4" /></button>
              <button onClick={() => setViewMode('mobile')} className={cn("p-1.5 rounded-lg transition-all", viewMode === 'mobile' ? "bg-white/10 text-white" : "text-zinc-500 hover:text-zinc-300")}><Smartphone className="w-4 h-4" /></button>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <SignedOut>
            <SignInButton mode="modal">
              <button className="px-5 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-sm font-medium transition-all">
                Sign In
              </button>
            </SignInButton>
          </SignedOut>
          <SignedIn>
            <div className="flex items-center gap-3">
              <div className="px-3 py-1 bg-accent-purple/10 border border-accent-purple/20 rounded-full text-[10px] font-bold text-accent-purple uppercase tracking-widest">
                {savedProjects.length}/10 Projects
              </div>
              <Link to="/dashboard" className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-sm font-medium transition-all">
                Dashboard
              </Link>
              {designs.length > 0 && (
                <button 
                  onClick={handleSave}
                  className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-accent-purple to-accent-blue rounded-full text-sm font-bold shadow-lg shadow-accent-purple/20 hover:opacity-90 transition-all"
                >
                  <Save className="w-4 h-4" /> Save
                </button>
              )}
              <UserButton afterSignOutUrl="/" />
            </div>
          </SignedIn>
        </div>
      </header>

      <main className="flex-1 flex relative z-10 overflow-hidden">
        <Routes>
          <Route path="/dashboard" element={
            <SignedIn>
              <Dashboard 
                projects={savedProjects} 
                onOpen={(p) => {
                  setDesigns([p]);
                  setSelectedIndex(0);
                  navigate('/');
                }}
                onDelete={handleDelete}
              />
            </SignedIn>
          } />
          
          <Route path="/" element={
            <div className="flex-1 flex overflow-hidden">
              {/* Sidebar: History/Variants */}
              <aside className="w-80 border-r border-white/5 bg-bg/50 backdrop-blur-xl flex flex-col shrink-0">
                <div className="p-4 border-b border-white/5 flex items-center justify-between">
                  <h2 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">History</h2>
                  <button onClick={() => setDesigns([])} className="p-1.5 hover:bg-white/5 rounded-lg transition-all text-zinc-500"><Plus className="w-4 h-4" /></button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
                  {designs.length > 0 ? (
                    designs.map((d, idx) => (
                      <button
                        key={d.id}
                        onClick={() => setSelectedIndex(idx)}
                        className={cn(
                          "w-full aspect-video rounded-2xl border-2 overflow-hidden transition-all group relative",
                          selectedIndex === idx ? "border-accent-purple shadow-2xl shadow-accent-purple/20 scale-[1.02]" : "border-white/5 hover:border-white/20"
                        )}
                      >
                        <div className="absolute inset-0 bg-zinc-900 flex items-center justify-center">
                          <Layout className="w-8 h-8 text-zinc-800" />
                        </div>
                        <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/90 to-transparent">
                          <div className="text-[11px] font-bold text-white truncate">{d.name}</div>
                        </div>
                        {selectedIndex === idx && (
                          <div className="absolute top-3 right-3 w-5 h-5 bg-accent-purple rounded-full flex items-center justify-center shadow-lg">
                            <Check className="w-3 h-3 text-white" />
                          </div>
                        )}
                      </button>
                    ))
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center p-8 opacity-50">
                      <Layers className="w-12 h-12 text-zinc-800 mb-4" />
                      <p className="text-sm text-zinc-600">Your design history will appear here.</p>
                    </div>
                  )}
                </div>
                
                <div className="p-4 border-t border-white/5 space-y-4 bg-white/[0.02]">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Design Options</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-bold text-zinc-600 uppercase">Font</label>
                      <select 
                        value={selectedFont.name}
                        onChange={(e) => setSelectedFont(FONTS.find(f => f.name === e.target.value)!)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-[11px] focus:outline-none focus:border-accent-purple/50 transition-all"
                      >
                        {FONTS.map(f => <option key={f.name} value={f.name} className="bg-bg">{f.name}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-bold text-zinc-600 uppercase">Theme</label>
                      <select 
                        value={selectedTheme.name}
                        onChange={(e) => setSelectedTheme(THEMES.find(t => t.name === e.target.value)!)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-[11px] focus:outline-none focus:border-accent-purple/50 transition-all"
                      >
                        {THEMES.map(t => <option key={t.name} value={t.name} className="bg-bg">{t.name}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
              </aside>

              {/* Main Preview Area */}
              <div className="flex-1 flex flex-col overflow-hidden relative">
                {designs.length === 0 ? (
                  <div className="flex-1 flex flex-col items-center justify-center p-12 text-center">
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="max-w-3xl w-full"
                    >
                      <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent-purple/10 border border-accent-purple/20 rounded-full text-[10px] font-bold text-accent-purple uppercase tracking-[0.2em] mb-8">
                        <Zap className="w-3 h-3" /> Next-Gen Vibe Coding
                      </div>
                      <h1 className="text-7xl font-bold tracking-tighter mb-8 leading-[0.9] gradient-text">
                        Code at the speed <br /> of thought.
                      </h1>
                      <div className="relative group max-w-2xl mx-auto mb-8">
                        <div className="absolute -inset-1 bg-gradient-to-r from-accent-purple to-accent-blue rounded-[2rem] blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
                        <div className="relative flex bg-bg/80 backdrop-blur-3xl border border-white/10 rounded-[2rem] overflow-hidden shadow-2xl">
                          <input
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                            placeholder={user ? "Describe your vision (e.g., A cinematic movie landing page...)" : "Sign in to start coding..."}
                            disabled={!user || isGenerating}
                            className="flex-1 px-8 py-6 bg-transparent text-lg focus:outline-none placeholder:text-zinc-700 disabled:cursor-not-allowed"
                          />
                          {user ? (
                            <button
                              onClick={() => handleGenerate()}
                              disabled={!prompt.trim() || isGenerating}
                              className="px-8 bg-gradient-to-r from-accent-purple to-accent-blue font-bold text-sm flex items-center gap-2 hover:opacity-90 transition-all active:scale-95"
                            >
                              {isGenerating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <ChevronRight className="w-5 h-5" />}
                            </button>
                          ) : (
                            <SignInButton mode="modal">
                              <button className="px-8 bg-gradient-to-r from-accent-purple to-accent-blue font-bold text-sm flex items-center gap-2 hover:opacity-90 transition-all active:scale-95">
                                Sign In <ChevronRight className="w-5 h-5" />
                              </button>
                            </SignInButton>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-wrap justify-center gap-2 max-w-2xl mx-auto">
                        {QUICK_CHIPS.map(chip => (
                          <button
                            key={chip}
                            onClick={() => handleGenerate(chip)}
                            className="px-4 py-2 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold text-zinc-500 hover:border-accent-purple/50 hover:text-white hover:bg-accent-purple/5 transition-all"
                          >
                            {chip}
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col overflow-hidden relative bg-zinc-950">
                    {/* Preview Container */}
                    <div className="flex-1 p-8 overflow-hidden flex flex-col items-center relative">
                      <AnimatePresence mode="wait">
                        <motion.div
                          key={currentDesign.id}
                          initial={{ opacity: 0, y: 30, scale: 0.98 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          className={cn(
                            "bg-white rounded-[2.5rem] overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.5)] transition-all duration-700 relative border border-white/5",
                            viewMode === 'desktop' ? "w-full h-full" : "w-[400px] h-full"
                          )}
                        >
                          <div className="absolute top-6 right-6 z-50 flex gap-3">
                            <button onClick={() => setIsPreviewOpen(true)} className="p-3 bg-black/40 backdrop-blur-xl hover:bg-black/60 rounded-2xl text-white transition-all border border-white/10 shadow-2xl"><Maximize2 className="w-5 h-5" /></button>
                          </div>
                          <div className="w-full h-full overflow-y-auto no-scrollbar">
                            <div dangerouslySetInnerHTML={{ __html: currentDesign.html }} className="w-full h-full" />
                          </div>
                        </motion.div>
                      </AnimatePresence>

                      {/* Floating Refinement Bar */}
                      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-full max-w-3xl px-8">
                        <div className="vibe-card p-4 bg-bg/80 backdrop-blur-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex flex-col gap-4 border border-white/10 rounded-[2rem]">
                          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                            {QUICK_CHIPS.map(chip => (
                              <button
                                key={chip}
                                onClick={() => handleGenerate(chip)}
                                className="whitespace-nowrap px-4 py-2 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold text-zinc-400 hover:border-accent-purple/50 hover:text-white transition-all hover:bg-accent-purple/5"
                              >
                                {chip}
                              </button>
                            ))}
                          </div>
                          <div className="relative">
                            <input 
                              value={prompt}
                              onChange={(e) => setPrompt(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                              placeholder={user ? "Refine your design..." : "Sign in to refine..."}
                              disabled={!user || isGenerating}
                              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 pr-14 text-sm focus:outline-none focus:border-accent-purple/50 transition-all placeholder:text-zinc-700 disabled:cursor-not-allowed"
                            />
                            {user ? (
                              <button 
                                onClick={() => handleGenerate()}
                                disabled={!prompt.trim() || isGenerating}
                                className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center bg-accent-purple/10 text-accent-purple hover:bg-accent-purple hover:text-white rounded-xl transition-all shadow-lg"
                              >
                                {isGenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                              </button>
                            ) : (
                              <SignInButton mode="modal">
                                <button className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center bg-accent-purple/10 text-accent-purple hover:bg-accent-purple hover:text-white rounded-xl transition-all shadow-lg">
                                  <Send className="w-4 h-4" />
                                </button>
                              </SignInButton>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          } />
        </Routes>
      </main>

      {/* Loading Overlay */}
      <AnimatePresence>
        {isGenerating && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-bg/80 backdrop-blur-xl flex flex-col items-center justify-center p-6"
          >
            <div className="relative w-20 h-20 mb-6">
              <div className="absolute inset-0 border-4 border-accent-purple/20 rounded-full" />
              <div className="absolute inset-0 border-4 border-accent-purple border-t-transparent rounded-full animate-spin" />
              <Sparkles className="absolute inset-0 m-auto w-6 h-6 text-accent-purple animate-pulse" />
            </div>
            <h2 className="text-xl font-bold tracking-tight mb-2">Generating your vibe...</h2>
            <p className="text-zinc-500 font-mono text-xs animate-pulse">{STATUS_MESSAGES[statusIdx]}</p>
          </motion.div>
        )}
      </AnimatePresence>

      <PreviewModal 
        isOpen={isPreviewOpen} 
        onClose={() => setIsPreviewOpen(false)} 
        html={currentDesign?.html || ''} 
      />
    </div>
  );
};

export default function App() {
  return (
    <ClerkProvider publishableKey={CLERK_PUBLISHABLE_KEY}>
      <Router>
        <VibeCoderApp />
      </Router>
    </ClerkProvider>
  );
}
