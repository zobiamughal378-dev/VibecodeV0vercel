import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Minimize2 } from 'lucide-react';

interface PreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  html: string;
}

export const PreviewModal: React.FC<PreviewModalProps> = ({ isOpen, onClose, html }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="w-full h-full max-w-7xl bg-bg border border-white/10 rounded-2xl overflow-hidden flex flex-col shadow-2xl"
          >
            {/* macOS Style Header */}
            <div className="h-12 bg-white/5 border-b border-white/10 flex items-center justify-between px-4">
              <div className="flex gap-2">
                <button onClick={onClose} className="w-3 h-3 rounded-full bg-red-500 hover:bg-red-600 transition-colors" />
                <div className="w-3 h-3 rounded-full bg-amber-500" />
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
              </div>
              <div className="text-xs font-medium text-zinc-500 uppercase tracking-widest">Full Screen Preview</div>
              <button onClick={onClose} className="text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto bg-white">
              <div dangerouslySetInnerHTML={{ __html: html }} className="w-full h-full" />
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
