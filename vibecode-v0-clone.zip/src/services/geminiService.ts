import { GoogleGenAI, Type } from "@google/genai";

const GEMINI_MODEL = "gemini-3-flash-preview";

export interface LandingPageDesign {
  id: string;
  name: string;
  layoutType: string;
  html: string;
  description: string;
  timestamp: number;
}

export interface GenerationResult {
  designs: LandingPageDesign[];
}

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not set");
    }
    this.ai = new GoogleGenAI({ apiKey });
  }

  async generateDesigns(
    prompt: string, 
    options: { font: string; theme: string; previousDesigns?: LandingPageDesign[] }
  ): Promise<GenerationResult> {
    const systemInstruction = `
      You are VibeCoder AI, a world-class senior web engineer and lead product designer. 
      Your mission is to generate 3 unique, breathtakingly beautiful, and highly interactive landing page layouts.
      
      Design Philosophy:
      - Use "Design Recipes" for inspiration: Technical Dashboard, Editorial Magazine, Hardware Specialist, Dark Luxury, Brutalist Creative, Warm Organic, Atmospheric Immersive, Clean Utility, Oversized Typographic, Bold Background.
      - Prioritize intentional pairings: Typography, color, spacing, and interaction must reinforce the same mood.
      - Avoid "AI slop": No generic purple/blue gradients unless they are part of a sophisticated atmospheric design.
      
      Technical Requirements:
      1. Each layout MUST have exactly 7 sections in this order:
         - HERO: Big animated heading, prompt name as glowing text, particles background (CSS-based), CTA buttons, and stats (e.g., Rating: 9.8, Runtime: 120m, Score: A+).
         - ABOUT: Detailed story/description, team/director info cards with photos (placeholders).
         - FEATURES/SERVICES: 6 cards with icons (Lucide-like SVGs), hover animations, and descriptions.
         - GALLERY/PORTFOLIO: Grid layout with image placeholders and hover zoom/overlay effects.
         - TESTIMONIALS/PRICING: Review cards or pricing plans with a "Most Popular" badge.
         - CTA: Full-width gradient background, big heading, email input field, and action buttons.
         - FOOTER: Navigation links, social icons, and copyright.
      
      2. Visual Style & Animations:
         - Typography: Bold, expressive, and high-contrast.
         - Scroll Effects: Every section MUST use "fade-up" on scroll (IntersectionObserver).
         - Section Effects: Include floating elements, glowing buttons, morphing blobs (CSS), and subtle scan lines.
         - Responsiveness: Perfect mobile-first layout.
      
      3. Implementation Details:
         - Use Tailwind CSS 4.0 utility classes.
         - Include a <style> tag for complex animations (keyframes for blobs, scanlines, particles).
         - Include a <script> tag for IntersectionObserver (adding 'visible' class to '.reveal' elements) and functional elements (confetti on button click, form submission success).
         - Use high-quality placeholder images from picsum.photos.
      
      4. Output:
         - A complete HTML snippet (no <html>/<body> tags).
         - Cohesive color palette based on the requested theme: ${options.theme}.
         - Font family: ${options.font}.
      
      Layout Variants:
      - Variant 1: Immersive & Cinematic (Large typography, glassmorphism, atmospheric gradients).
      - Variant 2: Minimalist & Precise (Clean grids, high whitespace, subtle borders, technical feel).
      - Variant 3: Bold & Experimental (Brutalist elements, oversized type, vibrant accents, dynamic motion).
      
      Refinement Mode:
      If previous designs are provided, apply the user's new instructions (e.g., "make it pink", "add more glow") while maintaining the core structure and high-end aesthetic.
    `;

    console.log("Generating designs for prompt:", prompt);
    const response = await this.ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: [
        {
          role: "user",
          parts: [{ text: `User Prompt: ${prompt}${options.previousDesigns ? `\n\nExisting Designs Context: ${JSON.stringify(options.previousDesigns)}` : ""}` }],
        },
      ],
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            designs: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  name: { type: Type.STRING },
                  layoutType: { type: Type.STRING },
                  html: { type: Type.STRING },
                  description: { type: Type.STRING },
                },
                required: ["id", "name", "layoutType", "html", "description"],
              },
            },
          },
          required: ["designs"],
        },
      },
    });

    try {
      const result = JSON.parse(response.text || "{}") as GenerationResult;
      if (result.designs) {
        result.designs = result.designs.map((d, i) => ({
          ...d,
          id: `${Date.now()}-${i}`,
          timestamp: Date.now()
        }));
      }
      return result;
    } catch (error) {
      console.error("Failed to parse Gemini response:", error);
      throw new Error("Invalid response from AI");
    }
  }
}
