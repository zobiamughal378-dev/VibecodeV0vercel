import React from 'react';
import { 
  LayoutGrid, 
  History as HistoryIcon, 
  Settings as SettingsIcon, 
  Folder, 
  Trash2, 
  ExternalLink,
  User,
  Database
} from 'lucide-react';
import { motion } from 'motion/react';
import { LandingPageDesign } from '../services/geminiService';

interface DashboardProps {
  projects: any[];
  onOpen: (project: any) => void;
  onDelete: (id: string) => void;
}

const EXAMPLE_PROJECTS = [
  {
    id: 'ex-1',
    name: 'Cyberpunk E-Commerce',
    description: 'A neon-drenched shopping experience with high-motion animations and glassmorphism.',
    layoutType: 'Experimental',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'ex-2',
    name: 'Zen Architecture',
    description: 'Minimalist portfolio for high-end architects focusing on whitespace and precision.',
    layoutType: 'Minimalist',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'ex-3',
    name: 'Cinematic Travel',
    description: 'Immersive storytelling for luxury travel agencies with full-screen video backgrounds.',
    layoutType: 'Cinematic',
    createdAt: new Date().toISOString(),
  }
];

export const Dashboard: React.FC<DashboardProps> = ({ projects, onOpen, onDelete }) => {
  const [activeTab, setActiveTab] = React.useState<'projects' | 'history' | 'settings'>('projects');
  const displayProjects = projects.length > 0 ? projects : EXAMPLE_PROJECTS;

  return (
    <div className="flex h-full bg-bg w-full">
      {/* Sidebar */}
      <aside className="w-64 border-r border-white/5 flex flex-col p-4 shrink-0">
        <div className="space-y-2">
          <button 
            onClick={() => setActiveTab('projects')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'projects' ? 'bg-accent-purple/10 text-accent-purple border border-accent-purple/20' : 'text-zinc-400 hover:bg-white/5'}`}
          >
            <LayoutGrid className="w-5 h-5" />
            <span className="font-medium">Projects</span>
          </button>
          <button 
            onClick={() => setActiveTab('history')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'history' ? 'bg-accent-purple/10 text-accent-purple border border-accent-purple/20' : 'text-zinc-400 hover:bg-white/5'}`}
          >
            <HistoryIcon className="w-5 h-5" />
            <span className="font-medium">History</span>
          </button>
          <button 
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'settings' ? 'bg-accent-purple/10 text-accent-purple border border-accent-purple/20' : 'text-zinc-400 hover:bg-white/5'}`}
          >
            <SettingsIcon className="w-5 h-5" />
            <span className="font-medium">Settings</span>
          </button>
        </div>

        <div className="mt-auto p-4 bg-white/5 rounded-2xl border border-white/5">
          <div className="flex items-center justify-between text-xs text-zinc-500 mb-2">
            <span>Storage</span>
            <span>{projects.length}/10</span>
          </div>
          <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-accent-purple to-accent-blue transition-all duration-500"
              style={{ width: `${(projects.length / 10) * 100}%` }}
            />
          </div>
        </div>
      </aside>

      {/* Content */}
      <main className="flex-1 overflow-y-auto p-8">
        {activeTab === 'projects' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Saved Projects</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {displayProjects.map((p) => (
                <motion.div 
                  key={p.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="vibe-card p-5 group relative"
                >
                  {p.id.startsWith('ex-') && (
                    <div className="absolute top-4 right-4 px-2 py-0.5 bg-accent-purple/20 border border-accent-purple/30 rounded text-[8px] font-bold text-accent-purple uppercase tracking-tighter z-10">
                      Example
                    </div>
                  )}
                  <div className="w-full aspect-video bg-zinc-900 rounded-lg mb-4 flex items-center justify-center border border-white/5 group-hover:border-accent-purple/30 transition-colors">
                    <Folder className="w-8 h-8 text-zinc-700" />
                  </div>
                  <h3 className="font-bold mb-1 truncate">{p.name}</h3>
                  <p className="text-xs text-zinc-500 mb-4 line-clamp-2">{p.description}</p>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => !p.id.startsWith('ex-') && onOpen(p)}
                      disabled={p.id.startsWith('ex-')}
                      className="flex-1 flex items-center justify-center gap-2 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <ExternalLink className="w-4 h-4" /> {p.id.startsWith('ex-') ? 'Preview Only' : 'Open'}
                    </button>
                    {!p.id.startsWith('ex-') && (
                      <button 
                        onClick={() => onDelete(p.id)}
                        className="p-2 text-zinc-500 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Generation History</h2>
            <div className="space-y-4">
              {[...projects].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map((p) => (
                <div key={p.id} className="vibe-card p-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-accent-purple/10 flex items-center justify-center text-accent-purple">
                      <HistoryIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold">{p.name}</div>
                      <div className="text-xs text-zinc-500">{new Date(p.createdAt).toLocaleString()}</div>
                    </div>
                  </div>
                  <button 
                    onClick={() => onOpen(p)}
                    className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-sm transition-colors"
                  >
                    View
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="max-w-2xl">
            <h2 className="text-2xl font-bold mb-6">Settings</h2>
            <div className="space-y-8">
              <section className="vibe-card p-6">
                <div className="flex items-center gap-3 mb-4">
                  <User className="w-5 h-5 text-accent-purple" />
                  <h3 className="font-bold">Profile</h3>
                </div>
                <div className="space-y-4">
                  <p className="text-sm text-zinc-500">Manage your profile and preferences here.</p>
                </div>
              </section>

              <section className="vibe-card p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Database className="w-5 h-5 text-accent-blue" />
                  <h3 className="font-bold">Data Management</h3>
                </div>
                <p className="text-sm text-zinc-500 mb-4">Your projects are securely stored in our cloud database.</p>
              </section>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
